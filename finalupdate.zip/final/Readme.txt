%%%%%%%%%%%%%%%%%%%%%%%%% Task 1 %%%%%%%%%%%%%%%
The maps and yaml are ih the folder map.

%%%%%%%%%%%%%%%%%%%%%%%%% Task 2 %%%%%%%%%%%%%%%
Robot:TIAGO
Packages:simple_navigation_goals
Compilation:
$cd ros/workspace
$catkin_make
Execution:
$source devel/setup.bash 
$roslaunch simple_navigation_goals navi_tiago.launch


%%%%%%%%%%%%%%%%%%%%%%%%% Task 3 %%%%%%%%%%%%%%%
Robot:TIAGO
Packages:simple_navigation_goals
Compilation:
$cd ros/workspace
$catkin_make
Execution:
$source devel/setup.bash 
$roslaunch simple_navigation_goals lift_tiago.launch

