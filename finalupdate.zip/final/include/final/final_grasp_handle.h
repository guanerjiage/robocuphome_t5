#include <ros/ros.h>
#include <geometry_msgs/Point.h>

// MoveIt
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit_msgs/PlaceLocation.h>
#include <moveit_msgs/Grasp.h>

// TF2
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <std_srvs/Trigger.h>
#include <control_msgs/FollowJointTrajectoryAction.h>
typedef actionlib::SimpleActionClient<control_msgs::FollowJointTrajectoryAction> gripper_control_client;
typedef boost::shared_ptr< gripper_control_client>  gripper_control_client_Ptr;
typedef actionlib::SimpleActionClient<control_msgs::FollowJointTrajectoryAction> head_control_client;
typedef boost::shared_ptr< head_control_client>  head_control_client_Ptr;

class final_grasp_handle
{
private:
    geometry_msgs::Point object_position;
    geometry_msgs::Point robot_position;
    geometry_msgs::Point cola_position;
    geometry_msgs::Point apple_position;
    geometry_msgs::Point sprite_position;
    moveit::planning_interface::PlanningSceneInterface planning_scene_interface;

public:
    final_grasp_handle(/* args */);
    ~final_grasp_handle();
    void openGripper(trajectory_msgs::JointTrajectory& posture);
    void closedGripper(trajectory_msgs::JointTrajectory& posture);
    void createHeadClient(head_control_client_Ptr& actionClient);
    void addCollisionObjects();
    void addCollisionObjects_new();
    void openGripper_hard();
    bool pick(std::string s);
    bool place();
    void place_hard();
    void pick_hard();
    void tuckarm();
    float handle_pose_x = -4.037393;
    float handle_pose_y = -2.632823;
    float handle_pose_z = 1.086649;
    float refre_pose_x = -4.493060;
    float refre_pose_y = -2.455050;
    float refre_pose_z = 0;
    bool detect_flag=false;
    void move_head(double shift);
    void creategripperClient(gripper_control_client_Ptr& actionClient);
    void waypoints_open_gripper_goal(control_msgs::FollowJointTrajectoryGoal& goal);
    //bool pick(std_srvs::Trigger::Request &req, std_srvs::Trigger::Response &res);
    //bool place(std_srvs::Trigger::Request &req, std_srvs::Trigger::Response &res);
    void object_cb(const geometry_msgs::PointStamped::ConstPtr& msg);
    void robot_pose(const geometry_msgs::PoseStamped::ConstPtr& msg_pose);
};
