#include <ros/ros.h>
#include <std_srvs/Empty.h>
#include <geometry_msgs/Twist.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>
#include <moveit/move_group_interface/move_group_interface.h>
#include <string>
#include <vector>
#include <map>
#include <control_msgs/FollowJointTrajectoryAction.h>
#include <exception>
#include <std_srvs/Trigger.h>
#include <final/final_grasp_handle.h>
typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;
void init(ros::NodeHandle n)
{
  // initial localization

        std_srvs::Empty srv;
        ros::service::call("/global_localization", srv);
        ROS_INFO("call service global localization");
        // emulate key_tele
        ros::Publisher pub=n.advertise<geometry_msgs::Twist>("/mobile_base_controller/cmd_vel",100);
        geometry_msgs::Twist msg;
        msg.linear.x = 0;
        msg.linear.y = 0;
        msg.linear.z = 0;
        msg.angular.x = 0;
        msg.angular.y = 0;
        msg.angular.z = 2;
        int c = 30;
        while(c)
        {
                pub.publish(msg);
                ROS_INFO_STREAM("send message to turn "<<c);
                c--;
                ros::Duration(0.8).sleep();
        }
        ros::service::call("/move_base/clear_costmaps", srv);
        ROS_INFO("call service clear costmap");


  // move the head down to look the table
  ROS_INFO_STREAM("Move your head down.");
  //wait for 10 second to let homing finish
  ros::Duration(10).sleep();

}
int main(int argc, char** argv){
  ros::init(argc, argv, "final_move");
  ros::NodeHandle n;
  ros::AsyncSpinner spinner(1);
  ros::Publisher cmdVelPub = n.advertise<geometry_msgs::Twist>("/mobile_base_controller/cmd_vel", 100);
  geometry_msgs::Twist speed;
  spinner.start();
  //tell the action client that we want to spin a thread by default
  MoveBaseClient ac("move_base", true);
  final_grasp_handle lp;
  ros::Subscriber sub = n.subscribe("/Point3D",10, &final_grasp_handle::object_cb, &lp);

  ros::Subscriber sub_pose = n.subscribe("/pose",10, &final_grasp_handle::robot_pose, &lp);
  //wait for the action server to come up
  while(!ac.waitForServer(ros::Duration(5.0))){
    ROS_INFO("Waiting for the move_base action server to come up");
  }
  //init(n);
  move_base_msgs::MoveBaseGoal goal;
  goal.target_pose.header.frame_id = "map";
  goal.target_pose.header.stamp = ros::Time::now();
  //ros::Duration(10).sleep();

  while(1){
    goal.target_pose.pose.position.x=-3.45;
    goal.target_pose.pose.position.y=-2.5;
    goal.target_pose.pose.orientation.x=0.0;
    goal.target_pose.pose.orientation.y=0.0;
    goal.target_pose.pose.orientation.z=1.0;
    goal.target_pose.pose.orientation.w=0.038;

    ROS_INFO("Sending first goal");
    ac.sendGoal(goal);
    ac.waitForResult();
    if (ac.waitForResult())
    {
         //ros::Duration(0.8).sleep();
        // ros::Subscriber sub_pose = n.subscribe("/pose",10, &final_grasp_handle::robot_pose, &lp);
         break;
    }
        }
     lp.pick("cola");

     speed.linear.x = -1.0;
     speed.linear.y = 0.0;
     speed.linear.z = 0.0;
     speed.angular.x = 0;
     speed.angular.y = 0;// 设置线速度为0.1m/s，正为前进，负为后退
     speed.angular.z = 0; // 设置角速度为0rad/s，正为左转，负为右转
     int c = 10;
     while(c)
     {
             cmdVelPub.publish(speed);
             ROS_INFO_STREAM("send message to backup "<<c);
             c--;
             ros::Duration(0.5).sleep();
     }
  // ros::Duration(5.0);
  // ros::WallDuration(5.0).sleep();
   //speed.linear.x = 0.0; // 设置线速度为0.1m/s，正为前进，负为后退
 // speed.angular.z = 0; // 设置角速度为0rad/s，正为左转，负为右转
  // cmdVelPub.publish(speed);
  // lp.tuckarm();
   //ros::WallDuration(10.0).sleep();
  /* while(1){
     goal.target_pose.pose.position.x=-1.734852;
     goal.target_pose.pose.position.y=-0.648666;
     goal.target_pose.pose.orientation.x=0.0;
     goal.target_pose.pose.orientation.y=0.0;
     goal.target_pose.pose.orientation.z=1.0;
     goal.target_pose.pose.orientation.w=0.038;

     ROS_INFO("Sending second goal");
     ac.sendGoal(goal);
     ac.waitForResult();
     if (ac.waitForResult())
     {
          //ros::Duration(0.8).sleep();
         // ros::Subscriber sub_pose = n.subscribe("/pose",10, &final_grasp_handle::robot_pose, &lp);
          break;
     }
         }*/




   // lp.pick_hard();
  return 0;
}

