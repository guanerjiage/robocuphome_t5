#include <ros/ros.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>
#include <moveit/move_group_interface/move_group_interface.h>
typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;

int main(int argc, char** argv){
  ros::init(argc, argv, "simple_navigation_goals");

  //tell the action client that we want to spin a thread by default
  MoveBaseClient ac("move_base", true);

  //wait for the action server to come up
  while(!ac.waitForServer(ros::Duration(5.0))){
    ROS_INFO("Waiting for the move_base action server to come up");
  }
  move_base_msgs::MoveBaseGoal goal;
  goal.target_pose.header.frame_id = "map";
  goal.target_pose.header.stamp = ros::Time::now();

  while(1){
    goal.target_pose.pose.position.x=-3.0;
    goal.target_pose.pose.position.y=-2.4;
    goal.target_pose.pose.orientation.x=0.0;
    goal.target_pose.pose.orientation.y=0.0;
    goal.target_pose.pose.orientation.z=1.0;
    goal.target_pose.pose.orientation.w=0.0;

    ROS_INFO("Sending first goal");
    ac.sendGoal(goal);
    ac.waitForResult();

    if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
      ROS_INFO("First goal reached");   
    else
      ROS_INFO("The base failed to move to the goal for some reason");

    goal.target_pose.pose.position.x=-4;
    goal.target_pose.pose.position.y=-6.2;
    goal.target_pose.pose.orientation.z=1.0;
    goal.target_pose.pose.orientation.w=0.0;

    ROS_INFO("Sending second goal");
    ac.sendGoal(goal);
    ac.waitForResult();

    if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
      ROS_INFO("Second  goal reached");   
    else
      ROS_INFO("The base failed to move to the goal for some reason");

    goal.target_pose.pose.position.x=-1.4;
    goal.target_pose.pose.position.y=-11.8;
    goal.target_pose.pose.orientation.z=-0.7;
    goal.target_pose.pose.orientation.w=-0.7;

    ROS_INFO("Sending third goal");
    ac.sendGoal(goal);
    ac.waitForResult();

    if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
      ROS_INFO("Third goal reached");      
    else
      ROS_INFO("The base failed to move to the goal for some reason");
    
    // Lift table, first joint position
    std::map<std::string, double> target_position;

    target_position["torso_lift_joint"] = 0;
    target_position["arm_1_joint"] = 0.2;
    target_position["arm_2_joint"] = -1.34;
    target_position["arm_3_joint"] = -0.2;
    target_position["arm_4_joint"] = 1.94;
    target_position["arm_5_joint"] = -1.57;
    target_position["arm_6_joint"] = 0.03;
    target_position["arm_7_joint"] = 0.00;

    ros::NodeHandle nh;
    ros::AsyncSpinner spinner(1);
    spinner.start();

    std::vector<std::string> torso_arm_joint_names;
    //select group of joints
    moveit::planning_interface::MoveGroupInterface group_arm_torso("arm_torso");
    //choose your preferred planner
    group_arm_torso.setPlannerId("SBLkConfigDefault");

    torso_arm_joint_names = group_arm_torso.getJoints();

    group_arm_torso.setStartStateToCurrentState();
    group_arm_torso.setMaxVelocityScalingFactor(1.0);

    for (unsigned int i = 0; i < torso_arm_joint_names.size(); ++i)
      if ( target_position.count(torso_arm_joint_names[i]) > 0 )
      {
        ROS_INFO_STREAM("\t" << torso_arm_joint_names[i] << " goal position: " << target_position[torso_arm_joint_names[i]]);
        group_arm_torso.setJointValueTarget(torso_arm_joint_names[i], target_position[torso_arm_joint_names[i]]);
      }

    moveit::planning_interface::MoveGroupInterface::Plan my_first_plan;
    group_arm_torso.setPlanningTime(5.0);
    bool success_first = bool(group_arm_torso.plan(my_first_plan));

    if ( !success_first )
      throw std::runtime_error("No plan found");

    ROS_INFO_STREAM("Plan found in " << my_first_plan.planning_time_ << " seconds");

    // Execute the plan
    ros::Time start_first = ros::Time::now();  
    moveit::planning_interface::MoveItErrorCode error_first = group_arm_torso.move();
    if (!bool(error_first))
      throw std::runtime_error("Error executing plan");

    ROS_INFO_STREAM("Motion duration: " << (ros::Time::now() - start_first).toSec());

    spinner.stop();
    
    //second joint position
    target_position["arm_3_joint"] = -1.97;
    spinner.start();

    //choose your preferred planner
    group_arm_torso.setPlannerId("SBLkConfigDefault");
    torso_arm_joint_names = group_arm_torso.getJoints();
    group_arm_torso.setStartStateToCurrentState();
    group_arm_torso.setMaxVelocityScalingFactor(1.0);

    for (unsigned int i = 0; i < torso_arm_joint_names.size(); ++i)
      if ( target_position.count(torso_arm_joint_names[i]) > 0 )
      {
        ROS_INFO_STREAM("\t" << torso_arm_joint_names[i] << " goal position: " << target_position[torso_arm_joint_names[i]]);
        group_arm_torso.setJointValueTarget(torso_arm_joint_names[i], target_position[torso_arm_joint_names[i]]);
      }

    moveit::planning_interface::MoveGroupInterface::Plan second_plan;
    group_arm_torso.setPlanningTime(5.0);
    bool success_second = bool(group_arm_torso.plan(second_plan));

    if ( !success_second )
      throw std::runtime_error("No plan found");

    ROS_INFO_STREAM("Plan found in " << second_plan.planning_time_ << " seconds");

    // Execute the plan
    ros::Time start_second = ros::Time::now();
    moveit::planning_interface::MoveItErrorCode error_second = group_arm_torso.move();
    if (!bool(error_second))
      throw std::runtime_error("Error executing plan");

    ROS_INFO_STREAM("Motion duration: " << (ros::Time::now() - start_second).toSec());
    spinner.stop();

    //third joint position
    target_position["arm_2_joint"] = -0.8;
    spinner.start();

    //choose your preferred planner
    group_arm_torso.setPlannerId("SBLkConfigDefault");
    torso_arm_joint_names = group_arm_torso.getJoints();
    group_arm_torso.setStartStateToCurrentState();
    group_arm_torso.setMaxVelocityScalingFactor(1.0);

    for (unsigned int i = 0; i < torso_arm_joint_names.size(); ++i)
      if ( target_position.count(torso_arm_joint_names[i]) > 0 )
      {
        ROS_INFO_STREAM("\t" << torso_arm_joint_names[i] << " goal position: " << target_position[torso_arm_joint_names[i]]);
        group_arm_torso.setJointValueTarget(torso_arm_joint_names[i], target_position[torso_arm_joint_names[i]]);
      }

    moveit::planning_interface::MoveGroupInterface::Plan third_plan;
    group_arm_torso.setPlanningTime(5.0);
    bool success_third = bool(group_arm_torso.plan(third_plan));

    if ( !success_third )
      throw std::runtime_error("No plan found");

    ROS_INFO_STREAM("Plan found in " << third_plan.planning_time_ << " seconds");

    // Execute the plan
    ros::Time start_third = ros::Time::now();

    moveit::planning_interface::MoveItErrorCode error_third = group_arm_torso.move();
    if (!bool(error_third))
      throw std::runtime_error("Error executing plan");

    ROS_INFO_STREAM("Motion duration: " << (ros::Time::now() - start_third).toSec());
    spinner.stop();

    //fourth joint position
    target_position["arm_2_joint"] =-1.34;
    spinner.start();

    //choose your preferred planner
    group_arm_torso.setPlannerId("SBLkConfigDefault");
    torso_arm_joint_names = group_arm_torso.getJoints();
    group_arm_torso.setStartStateToCurrentState();
    group_arm_torso.setMaxVelocityScalingFactor(1.0);

    for (unsigned int i = 0; i < torso_arm_joint_names.size(); ++i)
      if ( target_position.count(torso_arm_joint_names[i]) > 0 )
      {
        ROS_INFO_STREAM("\t" << torso_arm_joint_names[i] << " goal position: " << target_position[torso_arm_joint_names[i]]);
        group_arm_torso.setJointValueTarget(torso_arm_joint_names[i], target_position[torso_arm_joint_names[i]]);
      }

    moveit::planning_interface::MoveGroupInterface::Plan fourth_plan;
    group_arm_torso.setPlanningTime(5.0);
    bool success_fourth = bool(group_arm_torso.plan(fourth_plan));

    if ( !success_fourth )
      throw std::runtime_error("No plan found");

    ROS_INFO_STREAM("Plan found in " << fourth_plan.planning_time_ << " seconds");

    // Execute the plan
    ros::Time start_fourth = ros::Time::now();
    moveit::planning_interface::MoveItErrorCode error_fourth = group_arm_torso.move();
    if (!bool(error_fourth))
      throw std::runtime_error("Error executing plan");

    ROS_INFO_STREAM("Motion duration: " << (ros::Time::now() - start_fourth).toSec());
    spinner.stop();

    //fifth joint position
    target_position["arm_3_joint"] = -0.2;
    spinner.start();
 
    //choose your preferred planner
    group_arm_torso.setPlannerId("SBLkConfigDefault");
    torso_arm_joint_names = group_arm_torso.getJoints();
    group_arm_torso.setStartStateToCurrentState();
    group_arm_torso.setMaxVelocityScalingFactor(1.0);

    for (unsigned int i = 0; i < torso_arm_joint_names.size(); ++i)
      if ( target_position.count(torso_arm_joint_names[i]) > 0 )
      {
        ROS_INFO_STREAM("\t" << torso_arm_joint_names[i] << " goal position: " << target_position[torso_arm_joint_names[i]]);
        group_arm_torso.setJointValueTarget(torso_arm_joint_names[i], target_position[torso_arm_joint_names[i]]);
      }

    moveit::planning_interface::MoveGroupInterface::Plan fifth_plan;
    group_arm_torso.setPlanningTime(5.0);
    bool success_fifth = bool(group_arm_torso.plan(fifth_plan));

    if ( !success_fifth )
      throw std::runtime_error("No plan found");

    ROS_INFO_STREAM("Plan found in " << fifth_plan.planning_time_ << " seconds");

    // Execute the plan
    ros::Time start_fifth = ros::Time::now();
    moveit::planning_interface::MoveItErrorCode error_fifth = group_arm_torso.move();
    if (!bool(error_fifth))
      throw std::runtime_error("Error executing plan");

    ROS_INFO_STREAM("Motion duration: " << (ros::Time::now() - start_fifth).toSec());
    spinner.stop();

    //sixth joint position
    target_position["arm_6_joint"] = 1.37;
    spinner.start();
    //choose your preferred planner
    group_arm_torso.setPlannerId("SBLkConfigDefault");
    torso_arm_joint_names = group_arm_torso.getJoints();
    group_arm_torso.setStartStateToCurrentState();
    group_arm_torso.setMaxVelocityScalingFactor(1.0);

    for (unsigned int i = 0; i < torso_arm_joint_names.size(); ++i)
      if ( target_position.count(torso_arm_joint_names[i]) > 0 )
      {
        ROS_INFO_STREAM("\t" << torso_arm_joint_names[i] << " goal position: " << target_position[torso_arm_joint_names[i]]);
        group_arm_torso.setJointValueTarget(torso_arm_joint_names[i], target_position[torso_arm_joint_names[i]]);
      }

    moveit::planning_interface::MoveGroupInterface::Plan sixth_plan;
    group_arm_torso.setPlanningTime(5.0);
    bool success_sixth = bool(group_arm_torso.plan(sixth_plan));

    if ( !success_sixth )
      throw std::runtime_error("No plan found");

    ROS_INFO_STREAM("Plan found in " << sixth_plan.planning_time_ << " seconds");

    // Execute the plan
    ros::Time start_sixth = ros::Time::now();
    moveit::planning_interface::MoveItErrorCode error_sixth = group_arm_torso.move();
    if (!bool(error_sixth))
      throw std::runtime_error("Error executing plan");

    ROS_INFO_STREAM("Motion duration: " << (ros::Time::now() - start_sixth).toSec());

    spinner.stop();

  }

  return 0;
}

