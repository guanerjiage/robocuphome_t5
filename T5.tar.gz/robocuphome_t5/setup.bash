cp -R ics_gazebo/tutorial5 ~/.pal/maps/configurations
